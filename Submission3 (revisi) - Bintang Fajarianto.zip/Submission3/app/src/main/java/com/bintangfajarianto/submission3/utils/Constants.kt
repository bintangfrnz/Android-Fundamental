package com.bintangfajarianto.submission3.utils

object Constants {
    const val BLANK: String = ""
    const val SPACE: String = " "
    const val DASH: String = "-"
    const val TAB_FOLLOWERS = 0
    const val TAB_FOLLOWING = 1
}